package com.smart.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;
import com.smart.entities.Contact;
import com.smart.entities.User;
import com.smart.healper.Message;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private ContactRepository contactRepository;

	// method for adding common data
	@ModelAttribute
	public void addCommonData(Model model, Principal principal) {
		String userName = principal.getName();
		System.out.println("USERNAME" + userName);
		// get user using username (emali)
		User user = userRepository.getUserByUserName(userName);

		System.out.println("USER" + user);
		model.addAttribute("user", user);
	}

	// dashboard home
	@RequestMapping("/index")
	public String dashboard(Model model, Principal principal) {

		return "normal/user_dashboard";
	}

	// open add form handlar
	@GetMapping("/add-contact")
	public String openAddContactForm(Model model) {
		model.addAttribute("title", "Add Contact");
		model.addAttribute("contact", new Contact());
		return "/normal/add_contact_form";
	}

	// processing add Contact form handlar
	@PostMapping("/process-contact")
	public String processingContact(@Valid @ModelAttribute Contact contact, BindingResult result,
			@RequestParam("image") MultipartFile file, Principal principal, HttpSession session) {
		try {
			String name = principal.getName();
			User user = this.userRepository.getUserByUserName(name);
			contact.setUser(user);

			// processing and uploading file
			if (file.isEmpty()) {
				// file is empty then try our message
				System.out.println("image field is empty !!");
				contact.setImage("contact.png");
			} else {
				// file upload
				contact.setImage(file.getOriginalFilename());

				File savefile = new ClassPathResource("/static/image").getFile();
				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + file.getOriginalFilename());
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

				System.out.println("yes  ");
			}
			user.getContacts().add(contact);
			this.userRepository.save(user);

			System.out.println("added to database");
			System.out.println("data" + contact);
			session.setAttribute("message", new Message("Successfully Add.....", "alert-success"));
			return "/normal/add_contact_form";
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("message", new Message("Not Add !..." + e.getMessage(), "alert-danger"));
			return "/normal/add_contact_form";
		}

	}

	// show contact
	// per page=5[n]
//	current page=0 [page]
	@GetMapping("/show-contacts/{page}")
	public String showContact(@PathVariable("page") Integer page, Model model, Principal principal) {
		model.addAttribute("title", "Show Contact");
		// contact list pathavyachi
		String userName = principal.getName();
		User user = this.userRepository.getUserByUserName(userName);
		Pageable pageable = PageRequest.of(page, 5);
		Page<Contact> contacts = this.contactRepository.findContactsByUser(user.getId(), pageable);

		model.addAttribute("contacts", contacts);
		model.addAttribute("currentpage", page);
		model.addAttribute("totalpage", contacts.getTotalPages());
		return "/normal/show_contact";
	}
	
	//SHOWING PERTICULAR CONTACT VALUE
	@RequestMapping("/{cId}/contact")
	public String showContactDetails(@PathVariable("cId")Integer cId,Model model,Principal principal) {
		
		
		model.addAttribute("title", "Show Details"); 
		
		Optional<Contact> optionalContact =  this.contactRepository.findById(cId);
		Contact contact=optionalContact.get();
		//check user
				String userName=principal.getName();
				User user = this.userRepository.getUserByUserName(userName);
				if (user.getId()==contact.getUser().getId()) {
					
					model.addAttribute("contact", contact); 
				}
		
		return "normal/show_details";
	}
	
	//delete contact handlar
	@GetMapping("/delete/{cid}")
	@Transactional
	public String deleteContact(@PathVariable("cid")Integer cId,Model model,Principal principal ,HttpSession session){
		
		Contact contact= this.contactRepository.findById(cId).get();
		
		//check assigement
		
		//delete old photo
		
		User user=this.userRepository.getUserByUserName(principal.getName());
		user.getContacts().remove(contact);
		this.userRepository.save(user);
		session.setAttribute("message",new Message("Contact Deleted Successfully ...","success"));
	return "redirect:/user/show-contacts/0";	
	}
	
	//open update form handler
	@PostMapping("/update-contact/{cid}")
	public String updateForm(@PathVariable("cid")Integer cid, Model model)
	
	{
		model.addAttribute("title","update contact");
		Contact contact= this.contactRepository.findById(cid).get();
		model.addAttribute("contact", contact);
		return "normal/update_form";
	}
	
	//update contact handlar
	@RequestMapping(value="/process-update",method=RequestMethod.POST)
	public String updateHandler(@Valid @ModelAttribute Contact contact,BindingResult result,@RequestParam("image") MultipartFile file
			,Model model,HttpSession session,Principal principal) {
		try {
			Contact oldcontactdetail=this.contactRepository.findById(contact.getCid()).get();
			//image
			if (!file.isEmpty()) {
				//file work
				//rewrite	
				//delete
				File deleteFile = new ClassPathResource("/static/image").getFile();
				File file1=new File(deleteFile,oldcontactdetail.getImage());
				file1.delete();
				//update
				File savefile = new ClassPathResource("/static/image").getFile();
				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + file.getOriginalFilename());
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				contact.setImage(file.getOriginalFilename());
				
			}else {
				contact.setImage(oldcontactdetail.getImage());
			}
			User user=this.userRepository.getUserByUserName(principal.getName());
			contact.setUser(user);
			this.contactRepository.save(contact);
			session.setAttribute("message",new Message("Contact Update Successfully ...","success"));
			return "redirect:/user/"+contact.getCid()+"/contact/";
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("message",new Message("Contact not Update  ...","danger"));
			return "redirect:/user/"+contact.getCid()+"/contact/";
		}
		
	}
	
	
	// profile  handlar
		@GetMapping("/profile")
		public String Profile(Model model) {
			model.addAttribute("title", "Profile");
			
			return "/normal/profile";
		}
}
